package com.samuel.apirest.Refugio;


import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RefugioService {

    private final RefugioRepository refugioRepo;

    public RefugioService(RefugioRepository refugioRepo) {
        this.refugioRepo = refugioRepo;
    }

    public void createRefugio(Refugio refugio) {
        refugioRepo.save(refugio);
    }

    public List<Refugio> getAllRefugios() {
        return refugioRepo.findAll();
    }

    public Optional<Refugio> getRefugioById(Integer id) {
        return refugioRepo.findById(id);
    }

    public void updateRefugio(Integer id, Refugio updatedRefugio) {
        Optional<Refugio> existingRefugio = refugioRepo.findById(id);
        existingRefugio.ifPresent(refugio -> {
            updatedRefugio.setId_refugio(id);
            refugioRepo.save(updatedRefugio);
        });
    }

    public void deleteRefugio(Integer id) {
        refugioRepo.deleteById(id);
    }
}
