package com.samuel.apirest.Dueno;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DuenoService {

    private final DuenoRepository duenoRepo;

    public DuenoService(DuenoRepository duenoRepo) {
        this.duenoRepo = duenoRepo;
    }

    public void createDueno(Dueno dueno) {
        duenoRepo.save(dueno);
    }

    public List<Dueno> getAllDuenos() {
        return duenoRepo.findAll();
    }

    public Optional<Dueno> getDuenoById(Integer id) {
        return duenoRepo.findById(id);
    }

    public void updateDueno(Integer id, Dueno updatedDueno) {
        Optional<Dueno> existingDueno = duenoRepo.findById(id);
        existingDueno.ifPresent(dueno -> {
            updatedDueno.setIdDueno(id);
            duenoRepo.save(updatedDueno);
        });
    }

    public void deleteDueno(Integer id) {
        duenoRepo.deleteById(id);
    }
}

