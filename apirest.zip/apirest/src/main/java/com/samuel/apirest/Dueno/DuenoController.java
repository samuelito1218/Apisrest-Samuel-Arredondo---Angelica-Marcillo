package com.samuel.apirest.Dueno;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dueno")
public class DuenoController {

    private final DuenoService duenoService;

    public DuenoController(DuenoService duenoService) {
        this.duenoService = duenoService;
    }

    @PostMapping
    public ResponseEntity<Void> createDueno(@RequestBody Dueno dueno) {
        duenoService.createDueno(dueno);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Dueno>> getAllDuenos() {
        List<Dueno> duenos = duenoService.getAllDuenos();
        return new ResponseEntity<>(duenos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Dueno> getDuenoById(@PathVariable Integer id) {
        return duenoService.getDuenoById(id)
                .map(dueno -> new ResponseEntity<>(dueno, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateDueno(@PathVariable Integer id, @RequestBody Dueno updatedDueno) {
        duenoService.updateDueno(id, updatedDueno);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDueno(@PathVariable Integer id) {
        duenoService.deleteDueno(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

